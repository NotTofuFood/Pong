package Entitys;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glVertex2f;

public class Ball {

    public int x, y;
    private float colorRed, colorBlue, colorGreen;
    public boolean facing = false;
    
    
    public void setFacing(boolean facing) {
		this.facing = facing;
	}
	private int WIDTH = 15;
    public int getWIDTH() {
		return WIDTH;
	}


	public void setWIDTH(int wIDTH) {
		WIDTH = wIDTH;
	}


	public int getHEIGHT() {
		return HEIGHT;
	}
	public boolean getFace() {
		return facing;
	}

	public void setHEIGHT(int hEIGHT) {
		HEIGHT = hEIGHT;
	}
	private int HEIGHT = 15;
	private int SPEED = (int) 1.7;
	public Ball(int x, int y) {
        this.x = x;
        this.y = y;
     
        colorRed = 1f;
        colorBlue = 1f;
        colorGreen = 1f;
    }
	
	public void increaseBallSpeed() {
		SPEED+=0.5;
	}
 
	   public int getX() {
	    	return x;
	    }
	    public int getY() {
	    	return y;
	    }
    public void resetBall() {
    	x=300;
    	y=300;
    }
    public void move() {
    	if(!facing) {
    		x-=SPEED;
    	}
    }
    public void moveOther() {
    	if(facing) {
    		x+=SPEED;
    	}
    }
    public void draw() {
        glColor3f(colorRed, colorGreen, colorBlue);
        glBegin(GL_QUADS);

        glVertex2f(x, y);
       
        glVertex2f(x + 15, y);
 
        glVertex2f(x + 15, y + 15);
       
        glVertex2f(x, y + 15);
        glEnd();
    }
}
