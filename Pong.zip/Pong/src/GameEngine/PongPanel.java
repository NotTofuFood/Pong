package GameEngine;

import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_MODELVIEW;
import static org.lwjgl.opengl.GL11.GL_PROJECTION;
import static org.lwjgl.opengl.GL11.glClear;
import static org.lwjgl.opengl.GL11.glMatrixMode;
import static org.lwjgl.opengl.GL11.glOrtho;


import java.util.ArrayList;
import java.util.List;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;

import Entitys.Ball;
import Entitys.Player;
import Entitys.PlayerAI;



public class PongPanel {
    private static final List<Player> shapes = new ArrayList<Player>(1);

	public PongPanel() { 
		 try {
	            Display.setDisplayMode(new DisplayMode(1280, 800));
	            Display.setTitle("Pong ");
	            Display.create();
	        } catch (LWJGLException e) {
	            e.printStackTrace();
	            Display.destroy();
	            System.exit(1);
	        }
	        shapes.add(new Player(0, 05));
	        glMatrixMode(GL_PROJECTION);
	        glOrtho(0, 640, 480, 0, 1, -1);
	        glMatrixMode(GL_MODELVIEW);
	        Player b = new Player(0,0);
	        Ball ball = new Ball(300,300);
	        PlayerAI ai = new PlayerAI(590,0);
	        while (!Display.isCloseRequested()) {
	            glClear(GL_COLOR_BUFFER_BIT);
	            b.getBox().bind();
	           
	            while (Keyboard.next()) {
	                if (Keyboard.getEventKey() == Keyboard.KEY_DOWN) {
	                	b.moveDown();
	                } else  if (Keyboard.getEventKey() == Keyboard.KEY_UP) {
	                	b.moveUp();
	                } 
	            }
	            if(ball.getX() <= b.getX() + b.getWIDTH() && ball.getX() >= b.getX() && ball.getY() >= b.getY() && ball.getY() <= b.getY() + b.getHEIGHT()) {
	            	ball.setFacing(true);
	            	ball.moveOther();
	            	ball.increaseBallSpeed();
	            }
	            if(ball.getX() <= ai.getX() + ai.getWIDTH() && ball.getX() >= ai.getX() && ball.getY() >= ai.getY() && ball.getY() <= ai.getY() + ai.getHEIGHT()) {
	            	ball.setFacing(false);
	            	ball.increaseBallSpeed();
	            } 
	            if(ball.getX() <= -1) {
	            	System.out.println("Player 2 Score");
	            	ball.setFacing(true);
	            	ball.resetBall();
	            }
	            if(ball.getX() >= 600) {
	            	System.out.println("Player 1 Score");
	            	ball.setFacing(false);
	            	ball.resetBall();
	            }
	        
	            	b.draw();
	            	ai.draw();
	            	ai.moveAI();
	            ball.draw();
	            if(!ball.facing) {
	            ball.move();
	            } else {
	            	ball.moveOther();
	            }

	            Display.update();
	            Display.sync(120);
	        }

	        Display.destroy();
	    }
	}


