package Entitys;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glVertex2f;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Random;

import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;

public class PlayerAI {

    public int x, y;
    public boolean selected = false;
    private float colorRed, colorBlue, colorGreen;

    private Texture box;
    private int WIDTH = 50;
    public int getWIDTH() {
		return WIDTH;
	}


	public void setWIDTH(int wIDTH) {
		WIDTH = wIDTH;
	}


	public int getHEIGHT() {
		return HEIGHT;
	}


	public void setHEIGHT(int hEIGHT) {
		HEIGHT = hEIGHT;
	}
	private int HEIGHT = 150;
    public Texture getBox() {
		return box;
	}


	public PlayerAI(int x, int y) {
        this.x = x;
        this.y = y;
        colorRed = 1f;
        colorBlue = 1f;
        colorGreen = 1f;
    }
	public PlayerAI() {
	    
    }

    
    public int getX() {
    	return x;
    }
    public int getY() {
    	return y;
    }

    public void update(int dx, int dy) {
        x += dx;
        y += dy;
    }


    public void moveAI() {
    	Random r = new Random();
    	
    	if(r.nextInt(100) == 1&& y>=00) {
    		y-=20;
    	} else if(r.nextInt(100) == 2 && y<=200) {
    		y+=70;
    	}
    }
    public void draw() {
        glColor3f(colorRed, colorGreen, colorBlue);
        glBegin(GL_QUADS);

        glVertex2f(x, y);
       
        glVertex2f(x + 50, y);
 
        glVertex2f(x + 50, y + 150);
       
        glVertex2f(x, y + 150);
        glEnd();
    }
}
