package Entitys;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glVertex2f;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;

public class Player {

    public int x, y;
    public boolean selected = false;
    private float colorRed, colorBlue, colorGreen;

    private Texture box;
    private int WIDTH = 50;
    public int getWIDTH() {
		return WIDTH;
	}


	public void setWIDTH(int wIDTH) {
		WIDTH = wIDTH;
	}


	public int getHEIGHT() {
		return HEIGHT;
	}


	public void setHEIGHT(int hEIGHT) {
		HEIGHT = hEIGHT;
	}
	private int HEIGHT = 150;
    public Texture getBox() {
		return box;
	}


	public Player(int x, int y) {
        this.x = x;
        this.y = y;
        box = load("rec");

        colorRed = 1f;
        colorBlue = 1f;
        colorGreen = 1f;
    }
	public Player() {
	     box = load("rec");
    }


    private Texture load(String filename) {
    	
    	try {
			return TextureLoader.getTexture("PNG",  new FileInputStream(new File("res/" + filename + ".png")));
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
    	
    	return null;
    }
    
    
    public int getX() {
    	return x;
    }
    public int getY() {
    	return y;
    }

    public void update(int dx, int dy) {
        x += dx;
        y += dy;
    }


    public void moveDown() {
    	
    	y+=20;
    }
    public void moveUp() {
    	y-=20;
    }
    public void draw() {
        glColor3f(colorRed, colorGreen, colorBlue);
        glBegin(GL_QUADS);

        glVertex2f(0, y);
       
        glVertex2f(0 + 50, y);
 
        glVertex2f(0 + 50, y + 150);
       
        glVertex2f(0, y + 150);
        glEnd();
    }
}
